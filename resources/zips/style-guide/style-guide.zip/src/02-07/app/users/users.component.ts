import { Component } from '@angular/core';

@Component({
  template: '<div>users component</div>',
  selector: 'admin-users'
})
export class UsersComponent {}
