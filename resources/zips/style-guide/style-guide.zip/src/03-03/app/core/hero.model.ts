export class Hero {
  name: string;
  power: string;
}
