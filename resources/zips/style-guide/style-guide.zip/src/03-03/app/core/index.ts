export * from './hero-collector.service';
export * from './hero.model';
