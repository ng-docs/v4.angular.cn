import { Component } from '@angular/core';

@Component({
  selector: 'sg-app',
  template: '<input type="text" tohValidate>'
})
export class AppComponent { }
