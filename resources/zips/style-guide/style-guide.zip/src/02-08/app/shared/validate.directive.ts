import { Directive } from '@angular/core';

@Directive({
  selector: '[tohValidate]'
})
export class ValidateDirective {}
