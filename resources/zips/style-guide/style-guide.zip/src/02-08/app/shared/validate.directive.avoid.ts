import { Directive } from '@angular/core';
/* avoid */

@Directive({
  selector: '[validate]'
})
export class ValidateDirective {}
