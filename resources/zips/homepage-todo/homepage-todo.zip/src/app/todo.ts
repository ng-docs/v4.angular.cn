// Declare an interaface for type safety
export interface Todo {
  text: string;
  done: boolean;
}
