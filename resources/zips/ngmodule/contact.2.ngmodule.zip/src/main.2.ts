import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { AppModule }             from './app/app.module.2';

platformBrowserDynamic().bootstrapModule(AppModule);
